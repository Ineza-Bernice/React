
// import React, { Component } from 'react';
// import Task from './Task';
// import './App.css';

// class App extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       tasks: [],
//       filter: 'all'
//     };
//   }

//   handleAddTask = (taskName) => {
//     const newTask = {
//       id: Date.now(),
//       name: taskName,
//       completed: false
//     };
//     this.setState(prevState => ({
//       tasks: [...prevState.tasks, newTask]
//     }));
//   }

//   handleEditTask = (taskId, newName) => {
//     this.setState(prevState => ({
//       tasks: prevState.tasks.map(task => {
//         if (task.id === taskId) {
//           return { ...task, name: newName };
//         }
//         return task;
//       })
//     }));
//   }

//   handleDeleteTask = (taskId) => {
//     this.setState(prevState => ({
//       tasks: prevState.tasks.filter(task => task.id !== taskId)
//     }));
//   }

//   handleToggleTask = (taskId) => {
//     this.setState(prevState => ({
//       tasks: prevState.tasks.map(task => {
//         if (task.id === taskId) {
//           return { ...task, completed: !task.completed };
//         }
//         return task;
//       })
//     }));
//   }

//   handleFilterChange = (filter) => {
//     this.setState({ filter });
//   }

//   handleClearCompleted = () => {
//     this.setState(prevState => ({
//       tasks: prevState.tasks.filter(task => !task.completed)
//     }));
//   }

//   filterTasks = () => {
//     const { tasks, filter } = this.state;
//     switch (filter) {
//       case 'completed':
//         return tasks.filter(task => task.completed);
//       case 'incomplete':
//         return tasks.filter(task => !task.completed);
//       default:
//         return tasks;
//     }
//   }

//   render() {
//     const { tasks, filter } = this.state;
//     const filteredTasks = this.filterTasks();

//     return (
//       <div className='all'>
//         <h1 className='head'>ToDo List</h1>
//         <form action="">
//         <input type="text" id="taskInput" />
//         <button onClick={() => this.handleAddTask(document.getElementById('taskInput').value)}>Add Task</button>

//         <div className='one'>
//           <button onClick={() => this.handleFilterChange('all')} disabled={filter === 'all'}>All</button>
//           <button onClick={() => this.handleFilterChange('completed')} disabled={filter === 'completed'}>Completed</button>
//           <button onClick={() => this.handleFilterChange('incomplete')} disabled={filter === 'incomplete'}>Incomplete</button>
//         </div>

//         <ul>
//           {filteredTasks.map(task => (
//             <Task
//               key={task.id}
//               task={task}
//               onEditTask={this.handleEditTask}
//               onDeleteTask={this.handleDeleteTask}
//               onToggleTask={this.handleToggleTask}
//             />
//           ))}
//         </ul>

//         <button onClick={this.handleClearCompleted}>Clear Completed</button>
//         </form>
//       </div>
//     );
//   }
// }

// export default App;
import React, { Component } from 'react';
import Task from './Task';
import './App.css';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tasks: [],
      filter: 'all',
    };
  }

  addTask = (taskName) => {
    const newTask = {
      id: Date.now(),
      name: taskName,
      completed: false,
    };
    this.setState((prevState) => ({
      tasks: [...prevState.tasks, newTask],
    }));
  };

  editTask = (taskId, newName) => {
    this.setState((prevState) => ({
      tasks: prevState.tasks.map((task) =>
        task.id === taskId ? { ...task, name: newName } : task
      ),
    }));
  };

  deleteTask = (taskId) => {
    this.setState((prevState) => ({
      tasks: prevState.tasks.filter((task) => task.id !== taskId),
    }));
  };

  toggleTaskCompletion = (taskId) => {
    this.setState((prevState) => ({
      tasks: prevState.tasks.map((task) =>
        task.id === taskId ? { ...task, completed: !task.completed } : task
      ),
    }));
  };

  clearCompletedTasks = () => {
    this.setState((prevState) => ({
      tasks: prevState.tasks.filter((task) => !task.completed),
    }));
  };

  setFilter = (filter) => {
    this.setState({ filter });
  };

  render() {
    const { tasks, filter } = this.state;

    let filteredTasks;
    if (filter === 'completed') {
      filteredTasks = tasks.filter((task) => task.completed);
    } else if (filter === 'incomplete') {
      filteredTasks = tasks.filter((task) => !task.completed);
    } else {
      filteredTasks = tasks;
    }

    return (
      <div className="app">
        <h1>ToDo List</h1>
        <div className="add-task">
          <input
            type="text"
            placeholder="Enter task"
            id="taskInput"
            ref={(input) => (this.taskInput = input)}
          />
          <button
            onClick={() => {
              this.addTask(this.taskInput.value);
              this.taskInput.value = '';
            }}
          >
            Add Task
          </button>
        </div>
        <div className="filters">
          <button
            className={filter === 'all' ? 'active' : ''}
            onClick={() => this.setFilter('all')}
          >
            All
          </button>
          <button
            className={filter === 'completed' ? 'active' : ''}
            onClick={() => this.setFilter('completed')}
          >
            Completed
          </button>
          <button
            className={filter === 'incomplete' ? 'active' : ''}
            onClick={() => this.setFilter('incomplete')}
          >
            Incomplete
          </button>
        </div>
        <ul className="task-list">
          {filteredTasks.map((task) => (
            <Task
              key={task.id}
              task={task}
              onEdit={this.editTask}
              onDelete={this.deleteTask}
              onToggle={this.toggleTaskCompletion}
            />
          ))}
        </ul>
        <button className="clear-btn" onClick={this.clearCompletedTasks}>
          Clear Completed Tasks
        </button>
      </div>
    );
  }
}

export default App;

