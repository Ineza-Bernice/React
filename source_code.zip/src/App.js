import React from "react";
import CarSellForm from "./component/CarSellForm";

function App() {
  return (
    <div>
      <CarSellForm />
    </div>
  );
}

export default App;
